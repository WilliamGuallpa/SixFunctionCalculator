package app11;

import javax.swing.JOptionPane;

public class SixFunctionCalculator
{

	public SixFunctionCalculator()
	{
		String userChoice;
		String firsTermInput;
		String secondTermInput;
		while (true)
		{

			userChoice = userChoice();

			if (userChoice.equalsIgnoreCase("exit"))
			{
				functionSelector(userChoice, "0", "0");

			} else
			{
				functionSelector(userChoice, firstTermInput(), secondTermInput());

			}

		}

	}

	public String userChoice()
	{
		String userChoice;

		userChoice = JOptionPane.showInputDialog(null, "which function would you like to use? ");

		return userChoice;
	}

	public String firstTermInput()
	{
		String firstNumber;

		firstNumber = JOptionPane.showInputDialog(null, "Please enter the first number ");

		return firstNumber;

	}

	public String secondTermInput()
	{
		String secondNumber;

		secondNumber = JOptionPane.showInputDialog(null, "Please enter the second number ");

		return secondNumber;
	}

	public void functionSelector(String userChoice, String firstTerm, String secondTerm)
	{
		if (userChoice.equalsIgnoreCase("addition"))
		{
			doubleDisplay(additionFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("subtraction"))
		{
			doubleDisplay(subtractionFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("multiplication"))
		{
			doubleDisplay(multiplicationFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("division"))
		{
			doubleDisplay(divisionFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("modulus"))
		{
			doubleDisplay(modulusFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("integer division"))
		{
			intDisplay(integerDivisionFunction(firstTerm, secondTerm));
		} else if (userChoice.equalsIgnoreCase("exit"))
		{
			System.exit(0);
		} else
		{
			invalidInputDisplay();
			functionSelector(userChoice(), firstTermInput(), secondTermInput());
		}

	}

	public void invalidInputDisplay()
	{
		JOptionPane.showMessageDialog(null, "The input is invalid");
	}

	public double additionFunction(String firstTerm, String secondTerm)
	{
		double result;

		result = Integer.parseInt(firstTerm) + Integer.parseInt(secondTerm);

		return result;
	}

	public double subtractionFunction(String firstTerm, String secondTerm)
	{
		double result;

		result = Integer.parseInt(firstTerm) - Integer.parseInt(secondTerm);

		return result;
	}

	public double multiplicationFunction(String firstTerm, String secondTerm)
	{
		double result;

		result = Integer.parseInt(firstTerm) * Integer.parseInt(secondTerm);

		return result;
	}

	public double divisionFunction(String firstTerm, String secondTerm)
	{
		double result;

		result = Integer.parseInt(firstTerm) / Integer.parseInt(secondTerm);

		return result;
	}

	public double modulusFunction(String firstTerm, String secondTerm)
	{
		double result;

		result = Integer.parseInt(firstTerm) % Integer.parseInt(secondTerm);

		return result;
	}

	public int integerDivisionFunction(String firstTerm, String secondTerm)
	{
		int result;

		result = Integer.parseInt(firstTerm) / Integer.parseInt(secondTerm);

		return result;
	}

	public void doubleDisplay(double result)
	{
		JOptionPane.showMessageDialog(null, "The result is " + result);
	}

	public void intDisplay(int result)
	{
		JOptionPane.showMessageDialog(null, "The result is " + result);
	}
}
